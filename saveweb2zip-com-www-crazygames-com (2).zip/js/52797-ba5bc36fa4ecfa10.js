try{let e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},t=(new e.Error).stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="7d21e9a0-e972-4ae0-b4ea-d2d8187388e2",e._sentryDebugIdIdentifier="sentry-dbid-7d21e9a0-e972-4ae0-b4ea-d2d8187388e2")}catch(e){}{let e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{};e._sentryModuleMetadata=e._sentryModuleMetadata||{},e._sentryModuleMetadata[new e.Error().stack]=Object.assign({},e._sentryModuleMetadata[new e.Error().stack],{"_sentryBundlerPluginAppKey:crazygames-portal":!0})}"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[52797],{15327:(e,t,r)=>{r.d(t,{A:()=>d});var n,a=r(96540),i=r(21529),o=r(67558),s=r(53951);let l=(n||(n=r.t(a,2))).useSyncExternalStore;function d(e,t={}){let r=(0,s.A)(),n="undefined"!=typeof window&&void 0!==window.matchMedia,{defaultMatches:u=!1,matchMedia:h=n?window.matchMedia:null,ssrMatchMedia:p=null,noSsr:c=!1}=(0,o.A)({name:"MuiUseMediaQuery",props:t,theme:r}),m="function"==typeof e?e(r):e;return(void 0!==l?function(e,t,r,n,i){let o=a.useCallback(()=>t,[t]),s=a.useMemo(()=>{if(i&&r)return()=>r(e).matches;if(null!==n){let{matches:t}=n(e);return()=>t}return o},[o,e,n,i,r]),[d,u]=a.useMemo(()=>{if(null===r)return[o,()=>()=>{}];let t=r(e);return[()=>t.matches,e=>(t.addListener(e),()=>{t.removeListener(e)})]},[o,r,e]);return l(u,d,s)}:function(e,t,r,n,o){let[s,l]=a.useState(()=>o&&r?r(e).matches:n?n(e).matches:t);return(0,i.A)(()=>{let t=!0;if(!r)return;let n=r(e),a=()=>{t&&l(n.matches)};return a(),n.addListener(a),()=>{t=!1,n.removeListener(a)}},[e,r]),s})(m=m.replace(/^@media( ?)/m,""),u,h,p,c)}},21529:(e,t,r)=>{r.d(t,{A:()=>a});var n=r(96540);let a="undefined"!=typeof window?n.useLayoutEffect:n.useEffect},50065:(e,t,r)=>{r.d(t,{A:()=>h});var n=r(74848),a=r(16522),i=r(96540),o=r(90987),s=r.n(o),l=r(72762),d=r(32705),u=r(14276);let h=e=>{let t,r,o,h,p,c,m,g,f,y,w,b,v,A,x,k,M,C;let _=(0,a.c)(49),{canonical:j,title:S,description:R,imageUrl:E,imageWidth:$,imageHeight:I,imageQuality:L,type:T}=e,X=void 0===E?"crazygames/share.png":E,D=void 0===$?1200:$,N=void 0===I?630:I,{locale:z}=i.useContext(u.A);_[0]!==N||_[1]!==L||_[2]!==X||_[3]!==D?(t=(0,l.Ay)(X,{width:D,height:N,fit:"crop",quality:L}),_[0]=N,_[1]=L,_[2]=X,_[3]=D,_[4]=t):t=_[4];let H=t;return _[5]!==j?(r=(0,n.jsx)("meta",{property:"og:url",content:j}),_[5]=j,_[6]=r):r=_[6],_[7]!==S?(o=(0,n.jsx)("meta",{property:"og:title",content:S}),_[7]=S,_[8]=o):o=_[8],_[9]!==R?(h=(0,n.jsx)("meta",{property:"og:description",content:R}),_[9]=R,_[10]=h):h=_[10],_[11]!==z?(p=(0,d.qz)(z),_[11]=z,_[12]=p):p=_[12],_[13]!==p?(c=(0,n.jsx)("meta",{property:"og:locale",content:p}),_[13]=p,_[14]=c):c=_[14],_[15]!==H?(m=(0,n.jsx)("meta",{property:"og:image",content:H}),_[15]=H,_[16]=m):m=_[16],_[17]!==D?(g=D.toString(),_[17]=D,_[18]=g):g=_[18],_[19]!==g?(f=(0,n.jsx)("meta",{property:"og:image:width",content:g}),_[19]=g,_[20]=f):f=_[20],_[21]!==N?(y=N.toString(),_[21]=N,_[22]=y):y=_[22],_[23]!==y?(w=(0,n.jsx)("meta",{property:"og:image:height",content:y}),_[23]=y,_[24]=w):w=_[24],_[25]!==T?(b=T&&(0,n.jsx)("meta",{property:"og:type",content:T}),_[25]=T,_[26]=b):b=_[26],_[27]===Symbol.for("react.memo_cache_sentinel")?(v=(0,n.jsx)("meta",{property:"twitter:card",content:"summary_large_image"}),_[27]=v):v=_[27],_[28]!==j?(A=(0,n.jsx)("meta",{property:"twitter:url",content:j}),_[28]=j,_[29]=A):A=_[29],_[30]!==S?(x=(0,n.jsx)("meta",{property:"twitter:title",content:S}),_[30]=S,_[31]=x):x=_[31],_[32]!==R?(k=(0,n.jsx)("meta",{property:"twitter:description",content:R}),_[32]=R,_[33]=k):k=_[33],_[34]!==H?(M=(0,n.jsx)("meta",{property:"twitter:image",content:H}),_[34]=H,_[35]=M):M=_[35],_[36]!==m||_[37]!==f||_[38]!==w||_[39]!==b||_[40]!==A||_[41]!==x||_[42]!==k||_[43]!==M||_[44]!==r||_[45]!==o||_[46]!==h||_[47]!==c?(C=(0,n.jsxs)(s(),{children:[r,o,h,c,m,f,w,b,v,A,x,k,M]}),_[36]=m,_[37]=f,_[38]=w,_[39]=b,_[40]=A,_[41]=x,_[42]=k,_[43]=M,_[44]=r,_[45]=o,_[46]=h,_[47]=c,_[48]=C):C=_[48],C}},95715:(e,t,r)=>{r.d(t,{A:()=>_});var n=r(98587),a=r(58168),i=r(96540),o=r(34164),s=r(17437),l=r(75659),d=r(24279),u=r(50752),h=r(50285),p=r(38413),c=r(31609);function m(e){return(0,c.Ay)("MuiSkeleton",e)}(0,p.A)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var g=r(74848);let f=["animation","className","component","height","style","variant","width"],y=e=>e,w,b,v,A,x=e=>{let{classes:t,variant:r,animation:n,hasChildren:a,width:i,height:o}=e;return(0,l.A)({root:["root",r,n,a&&"withChildren",a&&!i&&"fitContent",a&&!o&&"heightAuto"]},m,t)},k=(0,s.i7)(w||(w=y`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)),M=(0,s.i7)(b||(b=y`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)),C=(0,u.Ay)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(e,t)=>{let{ownerState:r}=e;return[t.root,t[r.variant],!1!==r.animation&&t[r.animation],r.hasChildren&&t.withChildren,r.hasChildren&&!r.width&&t.fitContent,r.hasChildren&&!r.height&&t.heightAuto]}})(e=>{let{theme:t,ownerState:r}=e,n=String(t.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1]||"px",i=parseFloat(t.shape.borderRadius);return(0,a.A)({display:"block",backgroundColor:t.vars?t.vars.palette.Skeleton.bg:(0,d.X4)(t.palette.text.primary,"light"===t.palette.mode?.11:.13),height:"1.2em"},"text"===r.variant&&{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${i}${n}/${Math.round(i/.6*10)/10}${n}`,"&:empty:before":{content:'"\\00a0"'}},"circular"===r.variant&&{borderRadius:"50%"},"rounded"===r.variant&&{borderRadius:(t.vars||t).shape.borderRadius},r.hasChildren&&{"& > *":{visibility:"hidden"}},r.hasChildren&&!r.width&&{maxWidth:"fit-content"},r.hasChildren&&!r.height&&{height:"auto"})},e=>{let{ownerState:t}=e;return"pulse"===t.animation&&(0,s.AH)(v||(v=y`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),k)},e=>{let{ownerState:t,theme:r}=e;return"wave"===t.animation&&(0,s.AH)(A||(A=y`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),M,(r.vars||r).palette.action.hover)}),_=i.forwardRef(function(e,t){let r=(0,h.A)({props:e,name:"MuiSkeleton"}),{animation:i="pulse",className:s,component:l="span",height:d,style:u,variant:p="text",width:c}=r,m=(0,n.A)(r,f),y=(0,a.A)({},r,{animation:i,component:l,variant:p,hasChildren:!!m.children}),w=x(y);return(0,g.jsx)(C,(0,a.A)({as:l,ref:t,className:(0,o.A)(w.root,s),ownerState:y},m,{style:(0,a.A)({width:c,height:d},u)}))})}}]);